"use client";

import { cn } from "@/utils/cn";
import { HTMLMotionProps, motion } from "framer-motion";

// Replace interface with type definition for SlideIn props
type Props = HTMLMotionProps<"span">;

export const SlideIn = ({
    className,
    initial,
    whileInView,
    transition,
    viewport,
    ...rest
}: Props) => {
    const init = initial || { opacity: 0, y: "100%" };
    const inView = whileInView || { opacity: 1, y: 0 };
    const trans = transition || { duration: 0.5, delay: 0.3 };

    return (
        <motion.span
            initial={init}
            whileInView={inView}
            transition={trans}
            viewport={viewport || { once: true }}
            className={cn("inline-block overflow-hidden", className)}
            {...rest}
        />
    );
};

// Replace interface with type definition for Transition props
type TransitionProps = HTMLMotionProps<"div">;

export const Transition = ({
    initial,
    whileInView,
    transition,
    ...rest
}: TransitionProps) => {
    const init = initial || { opacity: 0 };
    const inView = whileInView || { opacity: 1 };
    const trans = transition || { duration: 0.8, delay: 0.4 };

    return (
        <motion.div
            initial={init}
            whileInView={inView}
            transition={trans}
            {...rest}
        />
    );
};

// Replace interface with type definition for FadeIn props
type FadeInProps = HTMLMotionProps<"div">;

export const FadeIn = ({ children, ...rest }: FadeInProps) => {
    return (
        <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            {...rest}
        >
            {children}
        </motion.div>
    );
};
